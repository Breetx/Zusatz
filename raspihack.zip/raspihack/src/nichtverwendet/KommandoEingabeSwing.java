package nichtverwendet;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import raspihack.Konstanten;

/**
 * Hilfsklasse für das grafische Einlesen einer String-Eingabe.
 */
public class KommandoEingabeSwing extends JFrame implements ActionListener, IKommandoEingabe {

    /**
   * 
   */
  private static final long serialVersionUID = -7939562841628653307L;

    /**
     * Diese Flag ist false so lange wie auf eine Eingabe gewartet wird (Klick
     * auf Ok bzw. Cancel).
     */
    private boolean eingabeFertig = true;

    /**
     * In dieses Textfeld wird die Eingabe eingetragen.
     *
     */
    private final JTextField textField;

    /**
     * Konstruktor.
     *
     * @param beschreibung Beschreibunsgtext für gültige Eingabe
     */
    public KommandoEingabeSwing(String beschreibung) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        getContentPane().add(panel);
        JLabel label = new JLabel("Kommando:");
        panel.add(label);
        textField = new JTextField("ende");
        panel.add(textField);
        JButton buttonOk = new JButton("Ok");
        buttonOk.setActionCommand(Konstanten.OK);
        buttonOk.addActionListener(this);
        panel.add(buttonOk);
        JButton buttonCancel = new JButton("Cancel");
        buttonCancel.setActionCommand(Konstanten.CANCEL);
        buttonCancel.addActionListener(this);
        panel.add(buttonCancel);
        JLabel labelBeschreibung = new JLabel(beschreibung);
        panel.add(labelBeschreibung);

        setSize(400, 200);
        setVisible(false);
    }

    @Override
    public String getEingabe() {
        setVisible(true);
        setEingabeFertig(false);
        Runnable eingabeThread = () -> {
            while (!getEingabeFertig()) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(KommandoEingabeSwing.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        Thread thread = new Thread(eingabeThread);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(KommandoEingabeSwing.class.getName()).log(Level.SEVERE, null, ex);
        }
        setVisible(false);
        return textField.getText();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case Konstanten.OK:
                setEingabeFertig(true);
                break;
            case Konstanten.CANCEL:
                setEingabeFertig(true);
                textField.setText("");
                break;
        }
    }

    /**
     * Setter.
     */
    public synchronized void setEingabeFertig(boolean eingabeFertig) {
        this.eingabeFertig = eingabeFertig;
    }

    /**
     * Getter.
     */ 
    public synchronized boolean getEingabeFertig() {
        return eingabeFertig;
    }

    @Override
    public void beenden() {
        dispose();
    }
    
    public static void main(String [] args ){
        KommandoEingabeSwing kommandoEingabe = new KommandoEingabeSwing("");
        String eingabe = kommandoEingabe.getEingabe();
        System.out.println("Eingabe: " + eingabe);
        kommandoEingabe.beenden();
    }
}
