package nichtverwendet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Eingabe eines Kommandos über die Konsole.
 */
public class KommandoEingabeKonsole implements IKommandoEingabe {

    /**
     * Ein Scanner-Objekt wird für die gesamte Programm-Laufzeit verwendet.
     *
     */
    private final Scanner scanner;

    /**
     * Konstruktor.
     *
     */
    KommandoEingabeKonsole() {
        scanner = new Scanner(System.in);
    }

    @Override
    public String getEingabe() {
        return getEingabeSystemIn();
    }

    /**
     * Liefert den Eingabe-String.
     *
     * @return Kommando-String.
     */
    public String getEingabeScanner() {
        System.out.println("Bitte Kommando eingeben: ");
        return  scanner.nextLine();
    }

    /**
     * Liefert den Eingabe-String.
     *
     * @return Kommando-String.
     */
    public String getEingabeSystemIn() {
        System.out.print("Bitte Kommando eingeben: ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String eingabe = "";
        try {
            eingabe = br.readLine();
        } catch (IOException ex) {
            Logger.getLogger(KommandoEingabeKonsole.class.getName()).log(Level.SEVERE, null, ex);
        }
        return eingabe;
    }
    
    @Override
    public void beenden() {
        scanner.close();
    }

    /**
     * Main-Methode zum Testen.
     * @param args Kommandozeilen-Parameter.
     **/
    public static void main(String[] args) {
        KommandoEingabeKonsole kommandoEingabe = new KommandoEingabeKonsole();
        String eingabe = kommandoEingabe.getEingabeSystemIn();
        System.out.println("Eingabe: " + eingabe);
        System.out.println("Done.");
    }
}
