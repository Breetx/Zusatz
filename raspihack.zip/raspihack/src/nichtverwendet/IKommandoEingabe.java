package nichtverwendet;

/**
 * Interface für verschiedene Arten der Kommando-Eingabe.
 */
public interface IKommandoEingabe {
    /**
     * Liefert den Eingabe-String.
     *
     * @return Kommando-String.
     */
    public String getEingabe();
    
    /**
     * Frame schliessen, damit Eingabe beenden.
     */
    public void beenden();
}
