package raspihack;

/**
 * Schnittstelle für LEDs.
 */
public interface ILed {

    /**
     * Schalterzustände.
     */
    public enum Schalter {
        AN, AUS
    }

    /**
     * Schalter setzen.
     *
     * @param schalter Neuer Schalterzustand.
     */
    public void schalte(Schalter schalter);
}
