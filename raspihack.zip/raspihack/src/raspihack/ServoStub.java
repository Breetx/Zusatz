package raspihack;

/**
 * Test-Stub für den Servo.
 */
public class ServoStub implements IServo {

    @Override
    public void bewegeZu(int winkel) {
        System.out.println("Bewege Servo zu Winkel " + winkel);
    }
}
