package raspihack;

import com.pi4j.io.gpio.RaspiPin;

import java.util.Scanner;

/**
 * Zentrale Anwendungsklasse.
 */
public class RaspiHackAnwendung {

  /**
   * Programmeinstieg - zentrale Anwendungs-Main-Methode.
   *
   */
  public static void main(String[] args) {
    Modell modell = new Modell();
    modell.ledHinzuFuegen(new Led(RaspiPin.GPIO_00));
    modell.ledHinzuFuegen(new Led(RaspiPin.GPIO_01));
    modell.servoHinzuFuegen(new Servo(60, 0, 150, 600));
    modell.ultraschallSensorHinzuFuegen(new UltraschallSensor(RaspiPin.GPIO_05,
        RaspiPin.GPIO_06));
    Scanner scanner = new Scanner(System.in);
    System.out.println("Kommandos: " + Konstanten.ENDE + " ODER "
        + Konstanten.LED + " <ID> " + Konstanten.AN + "|" + Konstanten.AUS
        + " ODER " + Konstanten.SERVO + " <ID> " + " <Winkel> ODER "
        + Konstanten.ENTFERNUNG + " <ID>");
    while (!modell.ende()) {
      System.out.print("Kommando: ");
      modell.verarbeite(scanner.nextLine());
    }
    scanner.close();
  }
}
