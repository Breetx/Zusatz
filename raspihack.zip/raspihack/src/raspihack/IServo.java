package raspihack;

/**
 * Gemeinsame Schnittstelle für alle Servos.
 */
public interface IServo {

    /**
     * Setzt den aktuellen Winkel des Servos.
     *
     * @param winkel Bereich zwischen -90 und +90 Grad (Gradmaß).
     */
    public void bewegeZu(int winkel);

}
