package raspihack;

import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;

/**
 * Ansteuerung einer LED für einen GPIO-Pin.
 */
public class Led implements ILed {

  /**
   * Pin auf dem GPIO board.
   */
  private final GpioPinDigitalOutput pin;

  /**
   * Id des Pins.
   */
  private final Pin pinId;

  /**
   * Konstructor.
   *
   * @param pinId
   *          GPIO-Pin-Id am Raspberry PI.
   */
  public Led(Pin pinId) {
    this.pinId = pinId;
    pin =
        GpioFactory.getInstance().provisionDigitalOutputPin(pinId, "LED",
            PinState.LOW);
  }

  @Override
  public void schalte(Schalter schalter) {
    switch (schalter) {
      case AN:
        pin.setState(PinState.HIGH);
        break;
      case AUS:
        pin.setState(PinState.LOW);
        break;
    }
  }

  @Override
  public String toString() {
    return "Led an Pin " + pinId;
  }

  /**
   * Testmethode.
   *
   * @param args
   *          Kommandozeilenparameter.
   */
  public static void main(String[] args) {
    Led led = new Led(RaspiPin.GPIO_01);
    led.schalte(ILed.Schalter.AN);
    try {
      Thread.sleep(2000);
    } catch (InterruptedException ex) {
      System.out.println("Sleeping interrupted.");
    }
    led.schalte(ILed.Schalter.AUS);
  }
}
