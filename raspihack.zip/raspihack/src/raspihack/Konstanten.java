package raspihack;

/**
 * Konstanten für die Kommandos.
 */
public interface Konstanten {
    public static final String ENDE = "ende";
    public static final String LED = "led";
    public static final String SERVO = "servo";
    public static final String ENTFERNUNG = "entfernung";
    public static final String OK = "ok";
    public static final String CANCEL = "cancel";
    public static final String AN = "an";
    public static final String AUS = "aus";
}
