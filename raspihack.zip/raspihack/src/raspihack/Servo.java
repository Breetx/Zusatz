package raspihack;

import adafruiti2c.servo.AdafruitPCA9685;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Steuerung eines Servos über das Adafruit board.
 */
public class Servo implements IServo {

  /**
   * Slot-Index auf dem Board [0...15].
   */
  private final int slotIndex;

  /**
   * Min Wert für PWM (-90 Grad).
   */
  private int servoMin = 150;

  /**
   * Max Wert für PWM (90 Grad).
   */
  private int servoMax = 600;

  /**
   * Adafruit-Board Schnittstelle.
   *
   */
  private AdafruitPCA9685 servoBoard;

  /**
   * Konstruktor.
   *
   * @param freq
   *          Frequenz zur Kommunikation mit dem Servo.
   * @param slotIndex
   *          Index des Servos auf dem Board.
   * @param servoMin
   *          Minimaler PWM.
   * @param servoMax
   *          Maximaler PWM.
   */
  public Servo(int freq, int slotIndex, int servoMin, int servoMax) {
    this.slotIndex = slotIndex;
    this.servoMin = servoMin;
    this.servoMax = servoMax;
    servoBoard = new AdafruitPCA9685();
    servoBoard.setPWMFreq(freq);
  }

  @Override
  public void bewegeZu(int winkel) {
    double servoPwm =
        servoMin + (servoMax - servoMin) * (winkel + 45.0) / 90.0;
    servoBoard.setPWM(slotIndex, 0, (int) servoPwm);
  }

  /**
   * Test-Anwendung.
   *
   * @param args
   *          Kommandozeilenparameter
   */
  public static void main(String[] args) {

    Servo servo = new Servo(60, 0, 150, 600);

    System.out.println("Gegen den Uhrzeigersinn.");
    servo.bewegeZu(-90);
    try {
      Thread.sleep(2000);
    } catch (InterruptedException ex) {
      Logger.getLogger(Servo.class.getName()).log(Level.SEVERE, null, ex);
    }

    System.out.println("Gegen den Uhrzeigersinn.");
    servo.bewegeZu(90);
    try {
      Thread.sleep(2000);
    } catch (InterruptedException ex) {
      Logger.getLogger(Servo.class.getName()).log(Level.SEVERE, null, ex);
    }

    System.out.println("Null.");
    servo.bewegeZu(-0);
    try {
      Thread.sleep(2000);
    } catch (InterruptedException ex) {
      Logger.getLogger(Servo.class.getName()).log(Level.SEVERE, null, ex);
    }

    System.out.println("Done.");
  }
}
