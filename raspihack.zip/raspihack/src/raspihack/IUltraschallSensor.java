/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package raspihack;

/**
 * Gemeinsame Schnittstelle für alle Entfernungssensoren basierend auf
 * Ultraschall.
 *
 * @author Philipp Jenke
 */
public interface IUltraschallSensor {

    /**
     * Liefert die aus 4 versuchen gemittelte Entfernung in cm.
     *
     * @return Entfernung in cm. -1, falls ein Fehler aufgetreten ist
     */
    public double getEntfernung();

    /**
     * Räumt die Verbindung zum Sensor auf. Keine Sensormessungen mehr möglich!
     *
     */
    public void shutdown();
}
