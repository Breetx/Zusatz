package raspihack;

/**
 * Test-Stub für eine Led.
 */
public class LedStub implements ILed {

    @Override
    public void schalte(Schalter schalter) {
        switch (schalter){
            case AN:
                System.out.println("LED Stub: An");
                break;
            case AUS:
                System.out.println("LED Stub: Aus");
                break;
        }
    }

}
