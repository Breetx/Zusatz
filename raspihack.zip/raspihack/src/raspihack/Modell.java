package raspihack;

import java.util.ArrayList;
import java.util.List;

/**
 * Verarbeitet Kommandos zu konkreten Aktionen an den Aktoren.
 */
public class Modell {

  /**
   * Dieses Flag gibt an, ob das Programm am Ende ist.
   *
   */
  private boolean istZuende = false;

  /**
   * Liste von Leds
   */
  private final List<ILed> leds;

  /**
   * Servo-Objekt.
   */
  private final List<IServo> servos;

  /**
   * Ultraschall-Sensor
   *
   */
  private final List<IUltraschallSensor> ultraschallSensoren;

  /**
   * Konstruktor.
   *
   * @param leds
   *          Liste von LEDs.
   * @param servo
   *          Servo-Objekt.
   */
  public Modell() {
    leds = new ArrayList<ILed>();
    servos = new ArrayList<IServo>();
    ultraschallSensoren = new ArrayList<IUltraschallSensor>();
  }

  /**
   * Neue Led in Liste aufnehmen.
   * 
   * @param led
   *          Neues LED-Objekt.
   */
  public void ledHinzuFuegen(ILed led) {
    leds.add(led);
  }

  /**
   * Neuen Servo in Liste aufnehmen.
   * 
   * @param servo
   *          Neues Servo-Objekt.
   */
  public void ultraschallSensorHinzuFuegen(IUltraschallSensor ultraschallSensor) {
    ultraschallSensoren.add(ultraschallSensor);
  }

  /**
   * Neuen Servo in Liste aufnehmen.
   * 
   * @param servo
   *          Neues Servo-Objekt.
   */
  public void servoHinzuFuegen(IServo servo) {
    servos.add(servo);
  }

  /**
   * Verarbeiten eines Kommandos, Ansprechen der Aktoren.
   *
   * @param eingabe
   *          Kommando zur Verarbeitung, Teile durch Leerzeichen getrennt.
   */
  public void verarbeite(String eingabe) {
    String[] tokens = eingabe.split("\\s+");
    if (tokens.length == 0) {
      return;
    }
    switch (tokens[0]) {
      case Konstanten.ENDE:
        System.out.println("Ende des Programms");
        istZuende = true;
        break;
      case Konstanten.LED:
        verarbeiteLed(tokens);
        break;
      case Konstanten.SERVO:
        verarbeiteServo(tokens);
        break;
      case Konstanten.ENTFERNUNG:
        verarbeiteUltraschall(tokens);
        break;
      default:
        System.out.println("Ungültiges Kommando: " + tokens[0]);
    }
  }

  /**
   * Liefert wahr, wenn das Ende-Kommando verarbeitet wurde.
   *
   * @return Flag zum Beendet-Zustand des Programms.
   */
  public boolean ende() {
    return istZuende;
  }

  /**
   * Verarbeitet ein LED-Kommando.
   */
  private void verarbeiteLed(String[] tokens) {
    if (tokens.length < 3) {
      System.out
          .println("LED kommando erwartet 2 Parameter: <index> und an|aus.");
      return;
    }

    // Index prüfen
    int ledIndex;
    try {
      ledIndex = Integer.parseInt(tokens[1]);
    } catch (NumberFormatException e) {
      System.out.format("Ungültiger LED index %s.\n", tokens[1]);
      return;
    }
    if (ledIndex >= leds.size()) {
      System.out.format("Ungültiger LED index %d.\n", ledIndex);
      return;
    }

    switch (tokens[2]) {
      case Konstanten.AN:
        leds.get(ledIndex).schalte(ILed.Schalter.AN);
        break;
      case Konstanten.AUS:
        leds.get(ledIndex).schalte(ILed.Schalter.AUS);
        break;
      default:
        System.out.format("Ungültiges LED kommando %s.\n", tokens[2]);
    }

  }

  /**
   * Verarbeitet ein Servo-Kommando.
   */
  private void verarbeiteServo(String[] tokens) {
    if (tokens.length < 3) {
      return;
    }

    // Index prüfen
    int servoIndex;
    try {
      servoIndex = Integer.parseInt(tokens[1]);
    } catch (NumberFormatException e) {
      System.out.format("Ungültiger Servo index %s.\n", tokens[1]);
      return;
    }
    if (servoIndex >= leds.size()) {
      System.out.format("Ungültiger Servo index %d.\n", servoIndex);
      return;
    }

    // Winkel prüfen
    int winkel;
    try {
      winkel = Integer.parseInt(tokens[2]);
    } catch (Exception e) {
      System.out.println("Ungültiger Wert für Winkel.");
      return;
    }
    if (winkel < -90 || winkel > 90) {
      System.out.println("Ungültiger Winkel");
      return;
    }
    servos.get(servoIndex).bewegeZu(winkel);
  }

  /**
   * Verarbeitet ein Ultraschall-Sensor kommando
   */
  private void verarbeiteUltraschall(String[] tokens) {

    if (tokens.length < 2) {
      return;
    }

    // Index prüfen
    int ultraschallSensorIndex;
    try {
      ultraschallSensorIndex = Integer.parseInt(tokens[1]);
    } catch (NumberFormatException e) {
      System.out.format("Ungültiger Servo index %s.\n", tokens[1]);
      return;
    }
    if (ultraschallSensorIndex >= leds.size()) {
      System.out.format("Ungültiger Servo index %d.\n", ultraschallSensorIndex);
      return;
    }

    System.out.format("Entfernung: %.1f cm\n",
        ultraschallSensoren.get(ultraschallSensorIndex).getEntfernung());
  }
}
